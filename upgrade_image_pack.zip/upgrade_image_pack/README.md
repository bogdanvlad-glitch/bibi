# Businessman Tycoon - pack d'images réelles pour upgrades

Ce dossier est prêt à être copié à côté de `index.html`.

## Contenu
- `assets_manifest.json` : toutes les images proposées, rangées par famille d'upgrade
- `mapping_example.json` : exemple de mapping entre les upgrades du jeu et les dossiers d'images
- `download_assets.py` : télécharge automatiquement les images réelles dans les sous-dossiers
- `upgrade-assets/` : destination finale des images téléchargées

## Comment l'utiliser
1. Place ce dossier dans le même dépôt que `index.html`
2. Lance :
   - `python3 download_assets.py`
3. Les images seront téléchargées dans `upgrade-assets/...`
4. Branche ensuite tes paths dans le HTML/JS

## Remarques
- Les URLs pointent vers des fichiers Wikimedia Commons via `Special:FilePath/...`
- Les images sont rangées par familles réutilisables : rayons, tables, fours, machines à café, salle de sport, salon, scooters/taxis, bus, joaillerie, pharmacie
- Tu peux enrichir `assets_manifest.json` avec d'autres images plus tard sans changer la structure
