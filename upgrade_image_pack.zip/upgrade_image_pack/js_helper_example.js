// Exemple simple pour brancher les images depuis le repo
async function loadUpgradeAssetManifest() {
  const res = await fetch('./upgrade_image_pack/assets_manifest.json');
  return res.json();
}

function pickFolderForUpgrade(upgradeId, mapping) {
  return mapping[upgradeId] || 'retail_shelves';
}

function buildLocalAssetPath(folder, filename) {
  return `./upgrade_image_pack/upgrade-assets/${folder}/${filename}`;
}
