#!/usr/bin/env python3
import json
import os
import pathlib
import ssl
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
MANIFEST = ROOT / 'assets_manifest.json'
OUTPUT_ROOT = ROOT / 'upgrade-assets'

ssl_context = ssl.create_default_context()
ssl_context.check_hostname = True
ssl_context.verify_mode = ssl.CERT_REQUIRED


def download(url: str, dest: pathlib.Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; BusinessmanTycoonAssetPack/1.0)'
    })
    with urllib.request.urlopen(req, context=ssl_context, timeout=60) as resp:
        data = resp.read()
    with open(dest, 'wb') as f:
        f.write(data)


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    ok = 0
    fail = 0
    for item in manifest['items']:
        dest = OUTPUT_ROOT / item['folder'] / item['filename']
        try:
            print(f"[DOWNLOAD] {item['label']} -> {dest}")
            download(item['download_url'], dest)
            ok += 1
        except Exception as e:
            fail += 1
            print(f"[ERROR] {item['download_url']} :: {e}")
    print(f"Done. success={ok} fail={fail}")


if __name__ == '__main__':
    main()
